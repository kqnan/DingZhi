package me.kqn.DropsOnDeath

import taboolib.common.platform.Plugin
import taboolib.common.platform.function.info

object DropsOnDeath : Plugin() {

    override fun onEnable() {
        info("Successfully running ExamplePlugin!")
    }
}