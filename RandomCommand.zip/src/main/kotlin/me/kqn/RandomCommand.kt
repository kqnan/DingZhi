package me.kqn

import taboolib.common.platform.Plugin
import taboolib.common.platform.function.info

object RandomCommand : Plugin() {

    override fun onEnable() {
        info("Successfully running ExamplePlugin!")
    }
}